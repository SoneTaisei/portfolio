#include "Object3d.hlsli"

static const int kMaxPointLights = 100;
static const int kMaxSpotLights = 100;

struct PixelShanderOutput
{
    float32_t4 color : SV_TARGET0;
};

//  環境マップ設定を追加し、パディングを調整
struct Material
{
    float32_t4 color;
    int32_t enableLighting;
    float32_t3 padding1;
    float32_t4x4 uvTransform;
    int32_t selectedLighting;
    float32_t shininess;
    int32_t materialType;
    float32_t roughness;
    float32_t metallic;
    
    int32_t enableNormalMap;
    int32_t enableEnvMap; // 追加: 環境マップON/OFF
    float envIntensity; // 追加: 環境マップ強度
    float emissive; // 自己発光の強さ
    float padding2; // 16バイトアライメント調整
};


struct DirectionalLight
{
    float32_t4 color;
    float32_t3 direction;
    float intenssity;
    float32_t3 ambientColor;
    float fogStart;
    float fogEnd;
    float32_t3 fogColor;
    float fogHeightMin; // 霧が最も濃い（100%溜まっている）高さ (例: -5.0f)
    float fogHeightMax; // 霧が完全に晴れる高さ (例: 5.0f)
    float volumetricIntensity;
    int volumetricSteps;
    int enableFog;
    float3 padding3;
    float32_t4x4 lightViewProj;
};

struct Camera
{
    float32_t3 worldPosition;
};

struct PointLight
{
    float32_t4 color;
    float32_t3 position;
    float intensity;
    float radius;
    float decay;
    float32_t2 padding;
};

struct PointLightConstData
{
    PointLight lights[kMaxPointLights];
    int activeCount;
    float32_t3 padding;
};

struct SpotLight
{
    float32_t4 color;
    float32_t3 position;
    float intensity;
    float32_t3 direction;
    float distance;
    float decay;
    float cosAngle;
    float cosFalloffStart;
    float32_t padding;
};

struct SpotLightConstData
{
    SpotLight lights[kMaxSpotLights];
    int activeCount;
    float32_t3 padding;
};

ConstantBuffer<Material> gMaterial : register(b0);
ConstantBuffer<DirectionalLight> gDirectionalLight : register(b1);
ConstantBuffer<Camera> gCamera : register(b2);
ConstantBuffer<PointLightConstData> gPointLights : register(b3);
ConstantBuffer<SpotLightConstData> gSpotLights : register(b4);

Texture2D<float32_t4> gTexture : register(t0);
TextureCube<float32_t4> gEnvTexture : register(t2);
SamplerState gSampler : register(s0);
Texture2D<float32_t4> gNormalMap : register(t3);
Texture2D<float32_t4> gOrmMap : register(t4);
Texture2D<float32_t> gShadowMap : register(t5);
SamplerState gShadowSampler : register(s1);

static const float PI = 3.14159265359;

float DistributionGGX(float3 N, float3 H, float roughness)
{
    float a = roughness * roughness;
    float a2 = a * a;
    float NdotH = max(dot(N, H), 0.0f);
    float NdotH2 = NdotH * NdotH;
    float num = a2;
    float denom = (NdotH2 * (a2 - 1.0f) + 1.0f);
    denom = PI * denom * denom;
    return num / max(denom, 0.0000001f);
}

float GeometrySchlickGGX(float NdotV, float roughness)
{
    float r = (roughness + 1.0f);
    float k = (r * r) / 8.0f;
    float num = NdotV;
    float denom = NdotV * (1.0f - k) + k;
    return num / max(denom, 0.0000001f);
}

float GeometrySmith(float3 N, float3 V, float3 L, float roughness)
{
    float NdotV = max(dot(N, V), 0.0f);
    float NdotL = max(dot(N, L), 0.0f);
    float ggx2 = GeometrySchlickGGX(NdotV, roughness);
    float ggx1 = GeometrySchlickGGX(NdotL, roughness);
    return ggx1 * ggx2;
}

float3 FresnelSchlick(float cosTheta, float3 F0)
{
    return F0 + (1.0f - F0) * pow(clamp(1.0f - cosTheta, 0.0f, 1.0f), 5.0f);
}

float Hash31(float3 p)
{
    return frac(sin(dot(p, float3(127.1f, 311.7f, 74.7f))) * 43758.5453f);
}

float ValueNoise3D(float3 p)
{
    float3 i = floor(p);
    float3 f = frac(p);
    float3 u = f * f * (3.0f - 2.0f * f);

    float n000 = Hash31(i + float3(0.0f, 0.0f, 0.0f));
    float n100 = Hash31(i + float3(1.0f, 0.0f, 0.0f));
    float n010 = Hash31(i + float3(0.0f, 1.0f, 0.0f));
    float n110 = Hash31(i + float3(1.0f, 1.0f, 0.0f));
    float n001 = Hash31(i + float3(0.0f, 0.0f, 1.0f));
    float n101 = Hash31(i + float3(1.0f, 0.0f, 1.0f));
    float n011 = Hash31(i + float3(0.0f, 1.0f, 1.0f));
    float n111 = Hash31(i + float3(1.0f, 1.0f, 1.0f));

    float nx00 = lerp(n000, n100, u.x);
    float nx10 = lerp(n010, n110, u.x);
    float nx01 = lerp(n001, n101, u.x);
    float nx11 = lerp(n011, n111, u.x);
    float nxy0 = lerp(nx00, nx10, u.y);
    float nxy1 = lerp(nx01, nx11, u.y);
    return lerp(nxy0, nxy1, u.z);
}

float FbmNoise3D(float3 p)
{
    float value = 0.0f;
    float amplitude = 0.5f;
    float frequency = 1.0f;

    [unroll]
    for (int i = 0; i < 4; ++i)
    {
        value += ValueNoise3D(p * frequency) * amplitude;
        frequency *= 2.03f;
        amplitude *= 0.5f;
    }

    return saturate(value);
}

float2 ProjectArmorCrackUV(float3 localPosition)
{
    float3 absPos = abs(localPosition);
    if (absPos.x > absPos.y && absPos.x > absPos.z)
    {
        return localPosition.yz;
    }
    if (absPos.y > absPos.z)
    {
        return localPosition.xz;
    }
    return localPosition.xy;
}

float ArmorBlockPanelMask(float3 localPosition, float2 faceUV)
{
    float3 absPos = abs(localPosition);
    float protrusion = max(max(absPos.x, absPos.y), absPos.z);
    float protrusionMask = 1.0f - smoothstep(1.002f, 1.035f, protrusion);
    float edgeMask = 1.0f - smoothstep(0.705f, 0.825f, max(abs(faceUV.x), abs(faceUV.y)));
    return saturate(protrusionMask * edgeMask);
}

float ArmorBlockRivetMask(float2 faceUV)
{
    float mask = 1.0f;
    [unroll]
    for (int y = -1; y <= 1; ++y)
    {
        [unroll]
        for (int x = -1; x <= 1; ++x)
        {
            float2 center = float2((float) x, (float) y) * 0.5f;
            mask *= smoothstep(0.095f, 0.165f, length(faceUV - center));
        }
    }
    return saturate(mask);
}

float DistanceToSegment2D(float2 p, float2 a, float2 b)
{
    float2 pa = p - a;
    float2 ba = b - a;
    float h = saturate(dot(pa, ba) / max(dot(ba, ba), 0.0001f));
    return length(pa - ba * h);
}

float CrackSegmentMask(float2 p, float2 a, float2 b, float width)
{
    float distance = DistanceToSegment2D(p, a, b);
    return 1.0f - smoothstep(width, width * 2.15f, distance);
}

float2 PixelateArmorUV(float2 uv)
{
    const float gridSize = 34.0f;
    return (floor(uv * gridSize) + 0.5f) / gridSize;
}

float ArmorCrackMask(float3 localPosition, float amount, float widthScale)
{
    float2 uv = ProjectArmorCrackUV(localPosition);
    float panelMask = ArmorBlockPanelMask(localPosition, uv);
    float rivetMask = ArmorBlockRivetMask(uv);
    float2 crackUV = PixelateArmorUV(uv);
    float width = lerp(0.010f, 0.018f, amount) * widthScale;
    float visibility = smoothstep(0.035f, 0.18f, amount);

    float mask = 0.0f;
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.58f, 0.34f), float2(-0.40f, 0.34f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.40f, 0.34f), float2(-0.40f, 0.12f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.40f, 0.12f), float2(-0.18f, 0.12f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.18f, 0.12f), float2(-0.18f, -0.10f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.18f, -0.10f), float2(0.06f, -0.10f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.06f, -0.10f), float2(0.06f, -0.30f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.06f, -0.30f), float2(0.34f, -0.30f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.34f, -0.30f), float2(0.34f, -0.12f), width));
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.34f, -0.12f), float2(0.62f, -0.12f), width));

    float branchA = smoothstep(0.12f, 0.34f, amount);
    float branchB = smoothstep(0.30f, 0.62f, amount);
    float branchC = smoothstep(0.52f, 0.86f, amount);
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.18f, 0.12f), float2(-0.34f, -0.04f), width * 0.82f) * branchA);
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.34f, -0.04f), float2(-0.52f, -0.04f), width * 0.82f) * branchA);
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.06f, -0.10f), float2(0.24f, 0.08f), width * 0.76f) * branchB);
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.24f, 0.08f), float2(0.48f, 0.08f), width * 0.76f) * branchB);
    mask = max(mask, CrackSegmentMask(crackUV, float2(0.34f, -0.30f), float2(0.52f, -0.46f), width * 0.70f) * branchC);
    mask = max(mask, CrackSegmentMask(crackUV, float2(-0.40f, 0.34f), float2(-0.54f, 0.50f), width * 0.70f) * branchC);

    return saturate(mask * visibility * panelMask * rivetMask);
}

float3 CalcPBRLight(float3 L, float3 V, float3 N, float3 radiance, float3 albedo, float roughness, float metallic, float3 F0)
{
    float3 H = normalize(V + L);
    float NDF = DistributionGGX(N, H, roughness);
    float G = GeometrySmith(N, V, L, roughness);
    float3 F = FresnelSchlick(max(dot(H, V), 0.0f), F0);
    float3 numerator = NDF * G * F;
    float denominator = 4.0f * max(dot(N, V), 0.0f) * max(dot(N, L), 0.0f) + 0.0001f;
    float3 specular = numerator / denominator;

    float3 kS = F;
    float3 kD = float3(1.0f, 1.0f, 1.0f) - kS;
    kD *= 1.0f - metallic;

    float NdotL = max(dot(N, L), 0.0f);
    return (kD * albedo / PI + specular) * radiance * NdotL;
}

PixelShanderOutput main(VecrtexShaderOutput input)
{
    PixelShanderOutput output;
    float4 transformedUV = mul(float32_t4(input.texcoord, 0.0f, 1.0f), gMaterial.uvTransform);
    float32_t4 textureColor = gTexture.Sample(gSampler, transformedUV.xy);
    
    if (gMaterial.materialType == 0 && textureColor.a <= 0.5)
    {
        discard;
    }
    
    float shadowFactor = 1.0f;

    // W除算 (同次座標系からデカルト座標系へ)
    float3 shadowPos = input.shadowPosition.xyz / input.shadowPosition.w;
    // クリップ空間(-1 ～ 1) を UV空間(0 ～ 1) に変換
    float2 shadowUV = float2(
        (shadowPos.x + 1.0f) / 2.0f,
        (1.0f - shadowPos.y) / 2.0f // Yは上下反転
    );

    // 画面外を真っ黒にしないための範囲チェック
    if (shadowPos.z > 0.0f && shadowPos.z < 1.0f &&
        shadowUV.x > 0.0f && shadowUV.x < 1.0f &&
        shadowUV.y > 0.0f && shadowUV.y < 1.0f)
    {
        float bias = 0.005f;
        shadowFactor = 0.0f;


        float2 texelSize = 1.0f / 2048.0f;
        float spread = 1.5f;

        for (int y = -1; y <= 1; ++y)
        {
            for (int x = -1; x <= 1; ++x)
            {
                // spread を掛けて、サンプリングする範囲を広げる
                float2 offset = float2(x, y) * texelSize * spread;
                float depthFromLight = gShadowMap.Sample(gShadowSampler, shadowUV + offset);
                
                if (shadowPos.z - bias <= depthFromLight)
                {
                    shadowFactor += 1.0f;
                }
            }
        }
        shadowFactor /= 9.0f;
    }
    float NdotL;
    float cos;
    
    switch (gMaterial.selectedLighting)
    {
        case 0: // None
            output.color = gMaterial.color * textureColor;
            break;

        case 1: // Lambert (Directional Only)
            cos = saturate(dot(normalize(input.normal), -gDirectionalLight.direction));
            output.color.rgb = gMaterial.color.rgb * textureColor.rgb * gDirectionalLight.color.rgb * cos * gDirectionalLight.intenssity;
            output.color.a = gMaterial.color.a * textureColor.a;
            break;

        case 2: // PBR (Cook-Torrance BRDF)
        {   
                float3 N = normalize(input.normal);
                float3 V = normalize(gCamera.worldPosition - input.worldPosition);

            // ===========================================================
            // ガラスシェーダー
            // ===========================================================
                if (gMaterial.materialType == 1)
                {
                    float NdotV = saturate(dot(N, V));
                    float iorRatio = 1.0f / 1.52f;
                    float3 IOR_RGB = float3(iorRatio * 0.99f, iorRatio, iorRatio * 1.01f);

                    float3 RefractR = refract(-V, N, IOR_RGB.r);
                    float3 RefractG = refract(-V, N, IOR_RGB.g);
                    float3 RefractB = refract(-V, N, IOR_RGB.b);

                    float3 envR = gEnvTexture.SampleLevel(gSampler, RefractR, 0.0f).rgb;
                    float3 envG = gEnvTexture.SampleLevel(gSampler, RefractG, 0.0f).rgb;
                    float3 envB = gEnvTexture.SampleLevel(gSampler, RefractB, 0.0f).rgb;
                    
                    // ★ gDirectionalLight から gMaterial に変更
                    float3 refractionColor = float3(envR.r, envG.g, envB.b) * gMaterial.envIntensity;
                    
                    float F0_glass = 0.04f;
                    float fresnel = F0_glass + (1.0f - F0_glass) * pow(1.0f - NdotV, 5.0f);
                    float darkRim = smoothstep(0.6f, 1.0f, 1.0f - pow(NdotV, 0.5f));

                    float3 ReflectVec = reflect(-V, N);
                    
                    // ★ gDirectionalLight から gMaterial に変更
                    float3 reflectionColor = gEnvTexture.SampleLevel(gSampler, ReflectVec, 0.0f).rgb * gMaterial.envIntensity;

                    float3 L_Dir = normalize(-gDirectionalLight.direction);
                    float3 H_glass = normalize(L_Dir + V);
                    float NdotH_glass = saturate(dot(N, H_glass));

                    float specPowerPrimary = 8192.0f;
                    float3 specPrimary = float3(1.0f, 1.0f, 1.0f) * pow(NdotH_glass, specPowerPrimary) * 5.0f;

                    float3 N_Back = normalize(N + V * 0.2f);
                    float NdotH_Back = saturate(dot(N_Back, H_glass));
                    float specPowerSecondary = 512.0f;
                    float3 specSecondary = float3(1.0f, 1.0f, 1.0f) * pow(NdotH_Back, specPowerSecondary) * 1.0f;
                    float3 totalSpecular = specPrimary + specSecondary;

                    float internalFocus = saturate(dot(N, -L_Dir));
                    float caustic = smoothstep(0.9f, 1.0f, internalFocus);
                    float3 fakeCaustics = float3(1.0f, 0.9f, 0.7f) * caustic * 2.0f;

                    float3 bodyColor = lerp(refractionColor * (1.0f - darkRim * 0.8f), reflectionColor, fresnel);
                    output.color.rgb = bodyColor + totalSpecular + fakeCaustics;

                    float alphaBase = 0.02f;
                    output.color.a = saturate(alphaBase + fresnel + caustic * 0.5f + (totalSpecular.r * 0.5f));
                }
            // ===========================================================
            // 魔氷（ソリッド＆ハイコントラスト）シェーダー
            // ===========================================================
                else if (gMaterial.materialType == 2)
                {
                    float NdotV = saturate(dot(N, V));
                    float3 baseColor = gMaterial.color.rgb * textureColor.rgb;

                    // 1. 完全フェイクの「鋭い」リムライト（輪郭発光）
                    // 以前のようなふんわりしたグラデーションではなく、
                    // smoothstepを使って「縁だけパキッと鋭く光る」硬い質感を作ります。
                    float rim = 1.0f - NdotV;
                    rim = smoothstep(0.5f, 1.0f, rim); // 0.5〜1.0の間で急激に光る
                    float3 rimColor = saturate(baseColor + float3(0.5f, 0.8f, 1.0f)) * rim * 3.0f;

                    // 2. 中心の深い色（透けさせない重厚感）
                    float3 coreColor = baseColor * 0.1f;

                    // 3. 環境マップを使った「内部の虹色反射」（★屈折は使いません！）
                    // 法線ベクトルを視線方向に無理やりズラすことで、内部で乱反射しているような嘘の景色を作ります。
                    // RGBごとにズラす幅を変えて、虹色に分解します。
                    float3 fakeNormalR = normalize(N + V * 0.4f);
                    float3 fakeNormalG = normalize(N + V * 0.6f);
                    float3 fakeNormalB = normalize(N + V * 0.8f);

                    float3 envR = gEnvTexture.SampleLevel(gSampler, reflect(-V, fakeNormalR), 0.0f).rgb;
                    float3 envG = gEnvTexture.SampleLevel(gSampler, reflect(-V, fakeNormalG), 0.0f).rgb;
                    float3 envB = gEnvTexture.SampleLevel(gSampler, reflect(-V, fakeNormalB), 0.0f).rgb;

                    // 虹色を取り出しつつ、乗算でコントラストを爆上げして「ギラッ」とさせる
                    float3 rainbowReflect = float3(envR.r, envG.g, envB.b);
                    rainbowReflect = pow(rainbowReflect, 2.0f) * gMaterial.envIntensity * 2.5f;

                    // そのギラッとした虹色を、氷のベースカラーで染める
                    float3 internalShine = rainbowReflect * baseColor * 2.0f;

                    // 4. 暴力的に鋭いハイライト（太陽光）
                    float3 L_Dir = normalize(-gDirectionalLight.direction);
                    float3 H = normalize(L_Dir + V);
                    float3 specular = float3(1.0f, 1.0f, 1.0f) * pow(saturate(dot(N, H)), 2048.0f) * 5.0f;

                    // 5. 最終合成
                    // コア色 ＋ 内部のギラつき ＋ 鋭いエッジ発光 ＋ ハイライト
                    output.color.rgb = coreColor + internalShine + rimColor + specular + (baseColor * gMaterial.emissive * 0.2f);
                    
                    // =======================================================
                    // アルファ値（透明度）
                    // =======================================================
                    // シャボン玉化を完全に防ぐため、基本は「ほぼ不透明（0.85）」にする
                    output.color.a = saturate(0.85f + rim + (specular.r * 0.5f)) * gMaterial.color.a;
                }
            // ===========================================================
            // ホログラム・バリア
            // ===========================================================
                else if (gMaterial.materialType == 3)
                {
                    float NdotV = saturate(dot(N, V));
                    float rimLight = pow(1.0f - NdotV, 3.0f);
                    float3 baseColor = gMaterial.color.rgb * textureColor.rgb;
                    float3 emission = baseColor * rimLight * 3.0f;
                    float3 frontColor = baseColor * 0.2f;
                    
                    output.color.rgb = emission + frontColor;
                    output.color.a = saturate(rimLight * 2.0f + 0.1f) * gMaterial.color.a * textureColor.a;
                }
            // ===========================================================
            // 消滅 (Dissolve)
            // ===========================================================
                else if (gMaterial.materialType == 4)
                {
                    float3 dissolvePos = input.worldPosition * 1.25f + normalize(input.normal) * 0.35f;
                    float coarseNoise = FbmNoise3D(dissolvePos);
                    float detailNoise = ValueNoise3D(dissolvePos * 4.5f) * 0.12f;
                    float noise = smoothstep(0.18f, 0.88f, saturate(coarseNoise * 0.92f + detailNoise));
                    float dissolveAmount = saturate(1.0f - gMaterial.color.a);

                    if (noise < dissolveAmount)
                    {
                        discard;
                    }
                    
                    float3 baseColor = gMaterial.color.rgb * textureColor.rgb;
                    float edgeWidth = lerp(0.075f, 0.045f, dissolveAmount);
                    float edgeMask = 1.0f - smoothstep(dissolveAmount, dissolveAmount + edgeWidth, noise);
                    edgeMask *= smoothstep(0.03f, 0.18f, dissolveAmount);

                    float3 N = normalize(input.normal);
                    float3 V = normalize(gCamera.worldPosition - input.worldPosition);
                    float3 ormColor = gOrmMap.Sample(gSampler, input.texcoord).rgb;
                    float roughness = max(0.04f, gMaterial.roughness * ormColor.g);
                    float metallic = gMaterial.metallic * ormColor.b;

                    if (gMaterial.enableNormalMap == 1)
                    {
                        float3 T = normalize(input.tangent);
                        T = normalize(T - dot(T, N) * N);
                        float3 B = cross(N, T);
                        float3x3 TBN = float3x3(T, B, N);
                        float3 normalMap = gNormalMap.Sample(gSampler, input.texcoord).rgb;
                        normalMap = normalMap * 2.0f - 1.0f;
                        N = normalize(mul(normalMap, TBN));
                    }

                    float3 F0 = float3(0.04f, 0.04f, 0.04f);
                    F0 = lerp(F0, baseColor, metallic);
                    float3 L_dir = normalize(-gDirectionalLight.direction);
                    float3 lightIntensity = lerp(float3(0.15f, 0.25f, 0.5f), float3(1.0f, 1.0f, 1.0f), shadowFactor);
                    float3 radiance = gDirectionalLight.color.rgb * gDirectionalLight.intenssity * lightIntensity;
                    float3 litColor = CalcPBRLight(L_dir, V, N, radiance, baseColor, roughness, metallic, F0);
                    float3 ambient = gDirectionalLight.ambientColor * baseColor * (1.0f - metallic);

                    if (gMaterial.enableEnvMap == 1)
                    {
                        float3 R = reflect(-V, N);
                        float3 envColor = gEnvTexture.SampleLevel(gSampler, R, roughness * 5.0f).rgb * gMaterial.envIntensity;
                        float3 F_ibl = FresnelSchlick(max(dot(N, V), 0.0f), F0);
                        ambient += envColor * F_ibl;
                    }

                    float3 edgeColor = (baseColor * 1.2f + float3(0.8f, 0.22f, 0.06f)) * edgeMask * 2.2f;
                    output.color.rgb = litColor + ambient + edgeColor;
                    output.color.a = 1.0f;
                }
            // ===========================================================
            // マグマ・覚醒 (Emissive)
            // ===========================================================
                else if (gMaterial.materialType == 5)
                {
                    float3 baseColor = gMaterial.color.rgb * textureColor.rgb;
                    
                    float luminance = dot(baseColor, float3(0.299f, 0.587f, 0.114f));
                    float glowFactor = smoothstep(0.4f, 0.0f, luminance);
                    float3 glowColor = float3(2.5f, 0.8f, 0.0f) * gMaterial.color.rgb;

                    float NdotL = saturate(dot(normalize(input.normal), -gDirectionalLight.direction));
                    float3 litColor = baseColor * gDirectionalLight.color.rgb * NdotL;
                    
                    output.color.rgb = litColor + (glowColor * glowFactor);
                    output.color.a = gMaterial.color.a * textureColor.a;
                }
            // ===========================================================
            // トゥーン調 (Cel Shaded)
            // ===========================================================
                else if (gMaterial.materialType == 6)
                {
                    float3 N = normalize(input.normal);
                    float3 L = normalize(-gDirectionalLight.direction);
                    float3 V = normalize(gCamera.worldPosition - input.worldPosition);
                    
                    float NdotL = dot(N, L);
                    float celFactor = (NdotL > 0.0f) ? 1.0f : 0.3f;
                    
                    float NdotV = saturate(dot(N, V));
                    float outline = (NdotV < 0.25f) ? 0.0f : 1.0f;
                    
                    float3 baseColor = gMaterial.color.rgb * textureColor.rgb;
                    float3 finalColor = baseColor * gDirectionalLight.color.rgb * celFactor;
                    
                    output.color.rgb = finalColor * outline;
                    output.color.a = gMaterial.color.a * textureColor.a;
                }
                else if (gMaterial.materialType == 7)
                {
                    // 1. C++から送られたUVスクロール(uvTransform)を適用してループさせる
                    float2 st = mul(float32_t4(input.texcoord, 0.0f, 1.0f), gMaterial.uvTransform).xy;
                    st = frac(st);

                    // 2. ノイズテクスチャの「赤チャンネル(白黒の濃淡)」を取得
                    float noise = gTexture.Sample(gSampler, st).r;

                    // 3. ★魔法の計算：smoothstepでノイズを「鋭いエネルギーの筋」に変換！
                    // ノイズの値が0.4以下は透明(0)に、0.6以上は真っ白(1)になるように補間します。
                    float energy = smoothstep(0.4f, 0.6f, noise);

                    // 4. ベースの色にエネルギーと自己発光(emissive)を掛け合わせる
                    output.color.rgb = gMaterial.color.rgb * energy * gMaterial.emissive;
                    
                    // 5. エネルギーがない(黒い)部分は透明にする
                    output.color.a = gMaterial.color.a * energy;

                    return output; // 影などを無視して強制終了
                }
           // ===========================================================
            // タイリングの継ぎ目を消す（仮想パディング）シェーダー
            // ===========================================================
                else if (gMaterial.materialType == 8)
                {
                    float2 st = mul(float32_t4(input.texcoord, 0.0f, 1.0f), gMaterial.uvTransform).xy;
                    float2 localUV = frac(st);

                    // 隙間を作る魔法の計算
                    float paddingScale = 1.2f;
                    localUV = (localUV - 0.5f) * paddingScale + 0.5f;

                    // 枠の外側を判定するマスク
                    float mask = step(0.0f, localUV.x) * step(localUV.x, 1.0f) * step(0.0f, localUV.y) * step(localUV.y, 1.0f);
                    float4 texColor = gTexture.Sample(gSampler, localUV);


                    if (mask == 0.0f || texColor.a < 0.1f)
                    {
                        discard; // ピクセル破棄（Zバッファにも書き込まない！）
                    }

                    // 生き残った「矢印の絵があるピクセル」だけ色を計算する
                    output.color.rgb = texColor.rgb * gMaterial.color.rgb * gMaterial.emissive;
                    output.color.a = texColor.a * gMaterial.color.a;

                    return output;
                }
            // ===========================================================
            // 通常のPBRマテリアル
            // ===========================================================
                else
                {
                    float3 ormColor = gOrmMap.Sample(gSampler, input.texcoord).rgb;
                    float roughness = gMaterial.roughness * ormColor.g;
                    float metallic = gMaterial.metallic * ormColor.b;
                    
                    float3 N = normalize(input.normal);

                    if (gMaterial.enableNormalMap == 1)
                    {
                        float3 T = normalize(input.tangent);
                        T = normalize(T - dot(T, N) * N);
                        float3 B = cross(N, T);
                        float3x3 TBN = float3x3(T, B, N);
                        float3 normalMap = gNormalMap.Sample(gSampler, input.texcoord).rgb;
                        normalMap = normalMap * 2.0f - 1.0f;
                        N = normalize(mul(normalMap, TBN));
                    }

                    float3 albedo = gMaterial.color.rgb * textureColor.rgb;
                    float3 F0 = float3(0.04f, 0.04f, 0.04f);
                    F0 = lerp(F0, albedo, metallic);

                    float3 Lo = float3(0.0f, 0.0f, 0.0f);

                    // 1. 平行光源
                    float3 L_dir = normalize(-gDirectionalLight.direction);
                    
                    // 【青みのある影のブレンド】
                    // shadowFactorが 0.0(影) の時は青い光、1.0(日向) の時は本来の光(白) になるように補間する
                    float3 shadowTint = float3(0.15f, 0.25f, 0.5f); // ★ここの数値で影の青さを調整できます！
                    float3 lightIntensity = lerp(shadowTint, float3(1.0f, 1.0f, 1.0f), shadowFactor);
                    
                    // 本来の光の強さに、青みを帯びたグラデーションを掛け合わせる
                    float3 radiance_dir = gDirectionalLight.color.rgb * gDirectionalLight.intenssity * lightIntensity;
                    
                    Lo += CalcPBRLight(L_dir, V, N, radiance_dir, albedo, roughness, metallic, F0);

                    // 2. 点光源
                    for (int i = 0; i < gPointLights.activeCount; ++i)
                    {
                        PointLight pLight = gPointLights.lights[i];
                        float3 L_point = pLight.position - input.worldPosition;
                        float distance = length(L_point);
                        L_point = normalize(L_point);
                        float attenuation = pow(saturate(-distance / pLight.radius + 1.0f), pLight.decay);
                        float3 radiance_point = pLight.color.rgb * pLight.intensity * attenuation;
                        Lo += CalcPBRLight(L_point, V, N, radiance_point, albedo, roughness, metallic, F0);
                    }

                    // 3. スポットライト
                    for (int j = 0; j < gSpotLights.activeCount; ++j)
                    {
                        SpotLight sLight = gSpotLights.lights[j];
                        float3 L_spot = sLight.position - input.worldPosition;
                        float distance = length(L_spot);
                        L_spot = normalize(L_spot);
                        float distanceFactor = pow(saturate(-distance / sLight.distance + 1.0f), sLight.decay);
                        float angleCos = dot(-L_spot, normalize(sLight.direction));
                        float falloffFactor = saturate((angleCos - sLight.cosAngle) / (sLight.cosFalloffStart - sLight.cosAngle));
                        float3 radiance_spot = sLight.color.rgb * sLight.intensity * distanceFactor * falloffFactor;
                        Lo += CalcPBRLight(L_spot, V, N, radiance_spot, albedo, roughness, metallic, F0);
                    }

                    // 4. 環境マップ (IBL)
                    float3 ambient = float3(0.0f, 0.0f, 0.0f);
                    
                    // ★ gDirectionalLight から gMaterial に変更
                    if (gMaterial.enableEnvMap == 1)
                    {
                        float3 R = reflect(-V, N);
                        const float MAX_REFLECTION_LOD = 5.0f;
                        float3 envColor = gEnvTexture.SampleLevel(gSampler, R, roughness * MAX_REFLECTION_LOD).rgb;
                        
                        // ★ gDirectionalLight から gMaterial に変更
                        envColor *= gMaterial.envIntensity;
                        
                        float3 F_ibl = FresnelSchlick(max(dot(N, V), 0.0f), F0);
                        float3 kS_ibl = F_ibl;
                        float3 kD_ibl = 1.0f - kS_ibl;
                        kD_ibl *= 1.0f - metallic;

                        float3 specular_ibl = envColor * F_ibl;
                        float3 diffuse_ibl = kD_ibl * albedo * gDirectionalLight.ambientColor;

                        ambient = diffuse_ibl + specular_ibl;
                    }
                    else
                    {
                        ambient = gDirectionalLight.ambientColor * albedo * (1.0f - metallic);
                    }

                    output.color.rgb = Lo + ambient;
                    output.color.a = gMaterial.color.a * textureColor.a;

                    if (gMaterial.materialType == 13)
                    {
                        float crackAmount = saturate(gMaterial.emissive - 1.0f);
                        float crackCore = ArmorCrackMask(input.localPosition, crackAmount, 0.58f);
                        float crackGroove = ArmorCrackMask(input.localPosition, crackAmount, 1.05f);
                        float crackLip = saturate(ArmorCrackMask(input.localPosition, crackAmount, 1.55f) - crackGroove);
                        float3 grooveColor = output.color.rgb * 0.36f;
                        float3 coreColor = output.color.rgb * 0.08f;
                        float3 lipColor = saturate(output.color.rgb + float3(0.16f, 0.18f, 0.20f));
                        output.color.rgb = lerp(output.color.rgb, grooveColor, crackGroove * 0.58f);
                        output.color.rgb = lerp(output.color.rgb, lipColor, crackLip * 0.44f);
                        output.color.rgb = lerp(output.color.rgb, coreColor, crackCore * 0.86f);
                    }
                }
                if (gDirectionalLight.enableFog != 0 && output.color.a > 0.0f)
                {
                
            // ===========================================================
            //  距離 ＋ ハイト（高さ）フォグ
            // ===========================================================
                    float3 fogColor = gDirectionalLight.fogColor;
                    float fogStart = gDirectionalLight.fogStart;
                    float fogEnd = gDirectionalLight.fogEnd;
                    float fogHeightMin = gDirectionalLight.fogHeightMin;
                    float fogHeightMax = gDirectionalLight.fogHeightMax;

                // ① 距離による霧の濃さ (0.0 ～ 1.0)
                    float distanceToCamera = length(input.worldPosition - gCamera.worldPosition);
                    float fogRange = max(fogEnd - fogStart, 0.01f);
                    float distanceFogFactor = saturate((distanceToCamera - fogStart) / fogRange);

                // ② 高さによる霧の濃さ (0.0 ～ 1.0)
                // 低い(Min)ほど 1.0 に近づき、高い(Max)ほど 0.0 になるように計算
                    float heightRange = max(fogHeightMax - fogHeightMin, 0.01f);
                    float heightFogFactor = 1.0f - saturate((input.worldPosition.y - fogHeightMin) / heightRange);

                // ③ 2つのフォグを掛け合わせる！（遠くて、かつ低い場所ほど濃くなる）
                    float finalFogFactor = distanceFogFactor * heightFogFactor;

                // ピクセルの色とフォグの色を合成
                    output.color.rgb = lerp(output.color.rgb, fogColor, finalFogFactor);
               // ===========================================================
               // ボリューメトリックフォグ (光の筋 / ゴッドレイ) の計算
               // ===========================================================
                    if (gDirectionalLight.volumetricIntensity > 0.0f && gDirectionalLight.volumetricSteps > 0)
                    {
                        float3 rayStart = gCamera.worldPosition;
                        float3 rayEnd = input.worldPosition;
                        float3 rayDir = rayEnd - rayStart;
                        float rayLength = length(rayDir);
                        rayDir = normalize(rayDir);
        
                    // あまり遠くまでレイを飛ばすと処理が重い＆ノイズになるので、計算距離を制限
                        float maxDistance = min(rayLength, 50.0f); // 50m先まで計算
                        float stepSize = maxDistance / (float) gDirectionalLight.volumetricSteps;
        
                        float scattering = 0.0f;
        
                     // レイマーチング (空間を少しずつ進むループ)
                        for (int i = 0; i < gDirectionalLight.volumetricSteps; ++i)
                        {
                       // 現在のチェック地点のワールド座標
                            float3 currentPos = rayStart + rayDir * (stepSize * i);
            
                       // ワールド座標から、シャドウマップ上の座標に変換
                            float4 shadowPos = mul(float4(currentPos, 1.0f), gDirectionalLight.lightViewProj);
                            shadowPos.xyz /= shadowPos.w;
            
            // UV座標系 (0.0 ~ 1.0) に変換
                            float2 shadowUV = float2(
                (shadowPos.x + 1.0f) / 2.0f,
                (1.0f - shadowPos.y) / 2.0f
            );
            
            // 画面外チェック
                            if (shadowPos.z > 0.0f && shadowPos.z < 1.0f &&
                shadowUV.x > 0.0f && shadowUV.x < 1.0f &&
                shadowUV.y > 0.0f && shadowUV.y < 1.0f)
                            {
                // シャドウマップからその地点の深度を取得（ループ内なので Sample ではなく SampleLevel を使う）
                                float depthFromLight = gShadowMap.SampleLevel(gShadowSampler, shadowUV, 0);
                
                // もし「日向（光が遮られていない）」なら、空気中の散乱光を加算！
                                if (shadowPos.z - 0.005f <= depthFromLight)
                                {
                                    scattering += 1.0f;
                                }
                            }
                        }
        
                       // 平均化して、指定した強さを掛ける
                        scattering = (scattering / (float) gDirectionalLight.volumetricSteps) * gDirectionalLight.volumetricIntensity;
        
                      // 光の筋の色を加算合成
                        float3 godRayColor = gDirectionalLight.color.rgb * gDirectionalLight.intenssity;
        
                       // ※透明なピクセルには足さない
                        if (output.color.a > 0.0f)
                        {
                            output.color.rgb += godRayColor * scattering;
                        }
                    }
                }
                if (gMaterial.emissive > 1.0f && gMaterial.materialType != 13)
                {
        // オブジェクト本来の色（光の影響なし）
                    float3 emissiveColor = gMaterial.color.rgb * textureColor.rgb;
        
        // 発光強度分だけ、最終出力カラーに加算する
                    output.color.rgb += emissiveColor * (gMaterial.emissive - 1.0f);
                }
                break;
            }
    }
  
    return output;
}
