
struct VSInput
{
    float4 position : POSITION0;
};

struct VSOutput
{
    float4 position : SV_POSITION;
};

cbuffer ObjectTransform : register(b0)
{
    matrix worldViewProjection; 
};

cbuffer ObjectColor : register(b1)
{
    float4 color; 
};